#include <stdio.h>

void printManPage(void);

int main(int argc, char **argv) {
	// Check to see if mknod has been run yet
	FILE * pFile;
	pFile = fopen("/dev/mytimer", "r+");
	if (pFile==NULL) {
		fputs("mytimer module isn't loaded\n",stderr);
		return -1;
	}

	// Read from pFile if argument is -l, list out all active timers
	if (argc == 2 && strcmp(argv[1], "-l") == 0) {
		// Read from file
		char buf[100];
		size_t bytes_read = fread(buf, 1, sizeof(buf), pFile);
	}

	// Write to pFile if argument is -m n_timers
	else if (argc == 3 && strcmp(argv[1], "-m") == 0) {
		char input_str[10];
		strcpy(input_str, argv[1]);
		strcat(input_str, " ");
		strcat(input_str, argv[2]);
		fwrite(input_str, sizeof(char), strlen(input_str), pFile);
	}
	
	// Write to pFile if argument is -s [MSG] 
	else if (argc == 4 && strcmp(argv[1], "-s") == 0) {
		// Send the input to the write function
		char input_str[136];
		strcpy(input_str, argv[1]);
		strcat(input_str, " ");
		strcat(input_str, argv[2]);
		strcat(input_str, " ");
		strcat(input_str, argv[3]);
		fwrite(input_str, sizeof(char), strlen(input_str), pFile);
	}
	
	else {
		printManPage();
		return 1;
	}
	
}

void printManPage() {
	printf("Error: invalid use.\n");
}

