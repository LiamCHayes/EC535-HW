#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/timer.h>
#include <linux/jiffies.h>
#include <linux/string.h>
#include <linux/slab.h>
#include <asm/uaccess.h> 

MODULE_LICENSE("Dual BSD/GPL");

// OTHER FUNCTIONS:
// Create a kernel timer that lasts for -s seconds
// Store the user supplied message with the timer so we can print it out when the timer ends
// Check if an active timer exists with the same message. If it does, reset the remaining time to the new -s seconds. Print out a message that the timer was updated
// If the message doesn't match, check if we have capacity for an additional timer. If not, print the error message

// Declaration of functions
static int mytimer_open(struct inode *inode, struct file *filp);
static int mytimer_release(struct inode *inode, struct file *filp);
static ssize_t mytimer_read(struct file *filp,
		char *buf, size_t count, loff_t *f_pos);
static ssize_t mytimer_write(struct file *filp,
		const char *buf, size_t count, loff_t *f_pos);
static void mytimer_exit(void);
static int mytimer_init(void);

struct file_operations mytimer_fops = {
	read: mytimer_read,
	write: mytimer_write,
	open: mytimer_open,
	release: mytimer_release
	kfree(data);
};

module_init(mytimer_init);
module_exit(mytimer_exit);

// Global variables for the driver
static int mytimer_major = 61;

// Timer things
struct timer_data {
	struct timer_list timer;
	char *message;
	size_t idx;
};
static size_t n_timers = 0;
static size_t max_timers = 1;
static struct timer_data timers[5];

static void mytimer_callback(struct timer_list *t) {
	struct timer_data *data = from_timer(data, t, timer);

	// When the timer ends, print the message that the user supplied
	printk(KERN_ALERT "%s\n", data->message);

	// Delete the timer
	size_t index = data->idx;
	del_timer(&timers[index].timer);

	// Move all elements in timers list down
	size_t i;
	for (i=index + 1; i < n_timers; i++) {
		timers[i-1] = timers[i];
		timers[i-1].idx = i - 1;
	}
	n_timers --;
	
}

// init function
static int mytimer_init(void) {
	// Initialize the timer module with the capacity for -m timers
	int result;

	// Register device major number
	result = register_chrdev(mytimer_major, "mytimer", &mytimer_fops);
	if (result < 0)
	{
		printk(KERN_ALERT "mytimer: cannot obtain major number %d\n", mytimer_major);
		return result;
	}

	printk(KERN_ALERT "Timer module loaded!\n");
	return 0;
fail:
	mytimer_exit();
	return result;
}

// exit function
static void mytimer_exit(void) {
	// Free the major number
	unregister_chrdev(mytimer_major, "mytimer");
	size_t i;
	for (i=0; i<max_timers; i++) {
		del_timer(&timers[i].timer);
	}

	printk(KERN_ALERT "Removing mytimer module\n");
}

// Open the device
static int mytimer_open(struct inode *inode, struct file *file) {
	    return 0;
}

// Release the device
static int mytimer_release(struct inode *inode, struct file *file) {
	    return 0;
}

// Read from the device
// handles the -l flag
static ssize_t mytimer_read(struct file *filp, char *buf, size_t count, loff_t *f_pos)
{
	// Execute timer printing logic
	size_t i;
	for (i=0; i < n_timers; i++) {
		// Check how many seconds are left
		unsigned long expires = timers[i].timer.expires;
		unsigned long time_left_jiffies = expires - jiffies;		
		struct timespec ts;
		jiffies_to_timespec(time_left_jiffies, &ts);
		long time_left_seconds = ts.tv_sec;
		char sec[8];
		scnprintf(sec, sizeof(sec), "%ld", time_left_seconds);

		// Create line to print
		char line[134];
		strncpy(line, timers[i].message, sizeof(line)-1);
		line[sizeof(line) - 1] = '\0';
		strlcat(line, " ", sizeof(line));
		strlcat(line, sec, sizeof(line));

		// Print line
		printk(KERN_ALERT "%s\n", line);
	}
	return 0;

}

// Write to the device
// handles the -s and -m flag
static ssize_t mytimer_write(struct file *filp, const char *buf, size_t count, loff_t *f_pos)
{
	// Create buffer to hold user input
	char kbuf[136];
	if (count > sizeof(kbuf) - 1) 
		return -EINVAL;

	// Copy user input to our buffer
	if (raw_copy_from_user(kbuf, buf, count)) 
		return -EFAULT;
	kbuf[count] = '\0';

	char *str = kbuf;
	char *token;
	token = strsep(&str, " ");

	// Execute timer logic 
	if (strcmp(token, "-s") == 0) {
		// Read len of timer
		token = strsep(&str, " ");
		long value;
		int ret;
		ret = kstrtol(token, 10, &value);
		if (ret != 0) {
			printk(KERN_ERR "Conversion to int failed\n");
		}
		size_t timer_len = (size_t)value * 1000;		

		// Check if message already exists
		size_t i;
		for (i=0; i<5; i++) {
			if (timers[i].message == NULL) {
				break;
			}
			if (strcmp(timers[i].message, str) == 0) {
				// We already have a timer with that message
				// Reset the remaining seconds to the new seconds 
				mod_timer(&timers[i].timer, jiffies + msecs_to_jiffies(timer_len));

				printk(KERN_ALERT "The timer %s was updated!", str);
				return count;
			}
		}

		// Check if we have room for anothe timer
		if (n_timers < max_timers) {
			// Create timer
			struct timer_data *data = kmalloc(sizeof(*data), GFP_KERNEL);
			timer_setup(&data->timer, mytimer_callback, 0);

			// Put message with timer
			data->message = kmalloc(strlen(str) + 1, GFP_KERNEL);
			strcpy(data->message, str);

			// Start timer
			data->timer.expires = jiffies + msecs_to_jiffies(timer_len);
			add_timer(&data->timer);

			// Add to list of timers
			data->idx = n_timers;
			timers[n_timers] = *data;
			n_timers ++;
		} else {
			printk(KERN_ALERT "%d timer(s) already exist(s)!", n_timers);
		}
	} else if (strcmp(token, "-m") == 0) {
		token = strsep(&str, " ");
		long value;
		int ret;
		ret = kstrtol(token, 10, &value);
		if (ret != 0) {
			printk(KERN_ERR "Conversion to int failed\n");
		}
		max_timers = (size_t)value;		
	}

	return count;
	
}

