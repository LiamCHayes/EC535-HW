/* Liam Hayes - liamh */

#ifndef BITS_H
#define BITS_H

unsigned int BinaryMirror(unsigned int);
unsigned int CountSequence(unsigned int);

#endif
